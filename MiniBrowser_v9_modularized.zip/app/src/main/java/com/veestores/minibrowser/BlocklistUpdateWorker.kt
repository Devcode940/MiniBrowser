package com.veestores.minibrowser

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * BlocklistUpdateWorker - Silent background fetcher for EasyList + EasyPrivacy
 * Runs once at first launch. Saves files to context.filesDir.
 */
class BlocklistUpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private val client = OkHttpClient()

    private suspend fun downloadToFile(url: String, dest: File) = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Failed download: ${'$'}{resp.code}")
            resp.body?.byteStream()?.use { input ->
                dest.outputStream().use { out -> input.copyTo(out) }
            } ?: throw IOException("Empty response body")
        }
    }

    override suspend fun doWork(): Result {
        try {
            val urls = listOf(
                "https://easylist.to/easylist/easylist.txt",
                "https://easylist.to/easylist/easyprivacy.txt"
            )
            for ((i, u) in urls.withIndex()) {
                val name = if (i == 0) "easylist_subset.txt" else "blocklist.txt"
                val file = File(applicationContext.filesDir, name)
                downloadToFile(u, file)
            }
            return Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            return Result.retry()
        }
    }
}
