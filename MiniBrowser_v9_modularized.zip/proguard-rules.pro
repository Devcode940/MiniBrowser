# Project-wide ProGuard rules
-keepclassmembers class kotlin.Metadata { *; }
-keep class kotlin.** { *; }
-dontwarn kotlin.**

# Keep coroutines internal classes used by reflection
-keep class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**

# Keep Android view binding generated classes (if used)
-keep class **_BindingClass { *; }

# Keep app package entrypoints and Activities
-keep public class com.veestores.minibrowser.** { public *; }
-keepclassmembers class com.veestores.minibrowser.** { *; }
