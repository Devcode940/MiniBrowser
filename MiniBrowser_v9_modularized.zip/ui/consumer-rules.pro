# Consumer ProGuard rules for UI module
-keep class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**
-keepclassmembers class kotlin.Metadata { *; }
