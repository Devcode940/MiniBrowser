package org.xmlpull.v1;
public interface XmlPullParser {
  int START_TAG=2, END_TAG=3, TEXT=4, END_DOCUMENT=1, IGNORABLE_WHITESPACE=7;
  void setInput(java.io.Reader r) throws XmlPullParserException, java.io.IOException;
  int getEventType() throws XmlPullParserException, java.io.IOException;
  int next() throws XmlPullParserException, java.io.IOException;
  String getName(); String getAttributeValue(String ns,String n); String getText(); int getDepth();
}
