package org.xmlpull.v1;
public class XmlPullParserFactory {
  public static XmlPullParserFactory newInstance() throws XmlPullParserException { return new XmlPullParserFactory(); }
  public void setNamespaceAware(boolean b){}
  public XmlPullParser newPullParser() throws XmlPullParserException { return null; }
}
