package org.json; public class JSONTokener { public JSONTokener(String s){} public Object nextValue() throws JSONException { return null; } }
