package org.json;
public class JSONArray {
  public JSONArray(){} public JSONArray(String s) throws JSONException {}
  public int length(){ return 0; }
  public String getString(int i) throws JSONException { return null; }
  public JSONObject getJSONObject(int i) throws JSONException { return null; }
  public JSONArray put(JSONObject o){ return this; }
}
