package androidx.appcompat.app;
import android.app.Activity; import android.os.Bundle;
public class AppCompatActivity extends Activity {
  protected void onCreate(Bundle b){} protected void onStart(){} protected void onStop(){}
}
