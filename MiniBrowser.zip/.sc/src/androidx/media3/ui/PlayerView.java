package androidx.media3.ui;
import android.content.Context; import android.util.AttributeSet; import android.widget.FrameLayout; import androidx.media3.common.Player;
public class PlayerView extends FrameLayout {
  public PlayerView(Context c){ super(c); } public PlayerView(Context c,AttributeSet a){ super(c,a); }
  public void setPlayer(Player p){} public void setUseController(boolean b){}
}
