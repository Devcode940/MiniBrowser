package androidx.media3.common;
public final class MediaItem {
  public static final class Builder {
    public Builder(){} public Builder setUri(Object u){ return this; } public Builder setMimeType(String m){ return this; } public MediaItem build(){ return null; }
  }
  public static MediaItem fromUri(Object u){ return null; }
}
