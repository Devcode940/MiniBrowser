package androidx.media3.common;
public interface Player {
  void setMediaItem(MediaItem m); void prepare(); void setPlayWhenReady(boolean b); boolean getPlayWhenReady();
  void release(); void addListener(Listener l);
  interface Listener { default void onVideoSizeChanged(VideoSize v){} }
}
