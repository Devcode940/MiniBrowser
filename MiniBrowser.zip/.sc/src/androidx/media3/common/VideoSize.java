package androidx.media3.common; public final class VideoSize { public int width, height; }
