package androidx.media3.common.util; import java.lang.annotation.*;
@Retention(RetentionPolicy.CLASS) public @interface UnstableApi {}
