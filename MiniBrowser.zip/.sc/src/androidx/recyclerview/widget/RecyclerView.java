package androidx.recyclerview.widget;
import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup; import android.view.View;
public class RecyclerView extends ViewGroup {
  public RecyclerView(Context c){ super(c); } public RecyclerView(Context c,AttributeSet a){ super(c,a); }
  public void setLayoutManager(LayoutManager l){} public void setAdapter(Adapter a){}
  public abstract static class LayoutManager {}
  public abstract static class Adapter<VH extends ViewHolder> {
    public abstract VH onCreateViewHolder(ViewGroup p,int vt);
    public abstract void onBindViewHolder(VH h,int pos);
    public abstract int getItemCount();
  }
  public abstract static class ViewHolder { public final View itemView; public ViewHolder(View v){ itemView=v; } }
}
