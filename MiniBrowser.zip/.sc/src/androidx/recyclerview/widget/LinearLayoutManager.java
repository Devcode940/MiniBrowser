package androidx.recyclerview.widget; import android.content.Context;
public class LinearLayoutManager extends RecyclerView.LayoutManager { public LinearLayoutManager(Context c){} }
