package androidx.recyclerview.widget;
public abstract class DiffUtil {
  public abstract static class Callback {
    public abstract int getOldListSize(); public abstract int getNewListSize();
    public abstract boolean areItemsTheSame(int o,int n); public abstract boolean areContentsTheSame(int o,int n);
  }
  public static DiffResult calculateDiff(Callback c){ return null; }
  public interface DiffResult { void dispatchUpdatesTo(RecyclerView.Adapter a); }
}
