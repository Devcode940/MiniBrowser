package androidx.core.content;
import android.net.Uri; import java.io.File;
public class FileProvider { public static Uri getUriForFile(android.content.Context c,String a,File f){ return null; } }
