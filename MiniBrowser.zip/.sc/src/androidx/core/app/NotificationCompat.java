package androidx.core.app;
import android.app.Notification;
public class NotificationCompat {
  public static final int PRIORITY_LOW=-1;
  public static class Builder {
    public Builder(android.content.Context c,String ch){}
    public Builder setSmallIcon(int i){ return this; } public Builder setContentTitle(CharSequence t){ return this; }
    public Builder setContentText(CharSequence t){ return this; } public Builder setProgress(int m,int p,boolean i){ return this; }
    public Builder setOngoing(boolean b){ return this; } public Builder setAutoCancel(boolean b){ return this; }
    public Builder setOnlyAlertOnce(boolean b){ return this; } public Builder setContentIntent(android.app.PendingIntent p){ return this; }
    public Builder setPriority(int p){ return this; } public Notification build(){ return null; }
  }
}
