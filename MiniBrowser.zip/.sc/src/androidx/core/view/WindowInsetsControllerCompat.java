package androidx.core.view;
public final class WindowInsetsControllerCompat {
  public static final int BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE=1;
  public void hide(int t){} public void show(int t){} public void setSystemBarsBehavior(int b){}
}
