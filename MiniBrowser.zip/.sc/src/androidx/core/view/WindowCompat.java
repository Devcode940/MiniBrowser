package androidx.core.view;
import android.view.View; import android.view.Window;
public final class WindowCompat {
  public static void setDecorFitsSystemWindows(Window w,boolean b){}
  public static WindowInsetsControllerCompat getInsetsController(Window w,View v){ return null; }
}
