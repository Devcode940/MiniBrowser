package androidx.core.view;
public final class WindowInsetsCompat { public static final class Type { public static int systemBars(){ return 0; } } }
