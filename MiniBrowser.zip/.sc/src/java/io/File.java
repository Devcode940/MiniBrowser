package java.io;
public class File {
  public File(String p){} public File(File p,String c){}
  public boolean exists(){ return false; } public boolean mkdirs(){ return false; } public boolean mkdir(){ return false; }
  public boolean delete(){ return false; } public boolean renameTo(File d){ return false; }
  public String getName(){ return null; } public String getAbsolutePath(){ return null; } public String getPath(){ return null; }
  public File[] listFiles(){ return null; } public boolean isFile(){ return false; }
  public java.nio.file.Path toPath(){ return null; }
}
