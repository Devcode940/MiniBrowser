package java.nio.file; public class Paths { public static Path get(String f,String... m){ return null; } }
