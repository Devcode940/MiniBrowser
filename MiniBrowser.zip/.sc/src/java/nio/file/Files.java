package java.nio.file; import java.io.IOException;
public class Files { public static byte[] readAllBytes(Path p) throws IOException { return new byte[0]; } }
