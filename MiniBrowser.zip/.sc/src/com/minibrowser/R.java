package com.minibrowser;
public final class R {
  public static final class layout {
    public static final int activity_download=1;
    public static final int activity_main=2;
    public static final int activity_notepad=3;
    public static final int activity_player=4;
    public static final int item_download=5;
    public static final int simple_spinner_dropdown_item=6;
    public static final int simple_spinner_item=7;
  }
  public static final class id {
    public static final int bottom_sheet=1;
    public static final int btn_back=2;
    public static final int btn_bookmark=3;
    public static final int btn_forward=4;
    public static final int btn_menu=5;
    public static final int btn_pip=6;
    public static final int btn_player_close=7;
    public static final int btn_reload=8;
    public static final int content=9;
    public static final int dl_add=10;
    public static final int dl_close=11;
    public static final int dl_delete=12;
    public static final int dl_empty=13;
    public static final int dl_list=14;
    public static final int dl_open=15;
    public static final int dl_pause=16;
    public static final int dl_progress=17;
    public static final int dl_share=18;
    public static final int dl_subtitle=19;
    public static final int dl_title=20;
    public static final int home_overlay=21;
    public static final int home_search=22;
    public static final int notepad_close=23;
    public static final int notepad_edit=24;
    public static final int notepad_status=25;
    public static final int player_view=26;
    public static final int progress=27;
    public static final int root=28;
    public static final int sheet_close=29;
    public static final int sheet_dots=30;
    public static final int sheet_next=31;
    public static final int sheet_pages=32;
    public static final int sheet_prev=33;
    public static final int sheet_title=34;
    public static final int shortcut_grid=35;
    public static final int toolbar=36;
    public static final int url_bar=37;
    public static final int webview=38;
  }
  public static final class drawable {
    public static final int dot_active=1;
    public static final int dot_inactive=2;
    public static final int ic_back=3;
    public static final int ic_bookmark_filled=4;
    public static final int ic_bookmark_outline=5;
    public static final int ic_close=6;
    public static final int ic_forward=7;
    public static final int ic_menu=8;
    public static final int ic_pause=9;
    public static final int ic_play=10;
    public static final int ic_send=11;
    public static final int stat_sys_download=12;
  }
  public static final class color {
    public static final int accent=1;
    public static final int active=2;
    public static final int black=3;
    public static final int c_about=4;
    public static final int c_agent=5;
    public static final int c_notepad=6;
    public static final int c_offline=7;
    public static final int c_qwen=8;
    public static final int danger=9;
    public static final int divider=10;
    public static final int primary=11;
    public static final int surface=12;
    public static final int surface_elevated=13;
    public static final int text_inverse=14;
    public static final int text_primary=15;
    public static final int text_secondary=16;
  }
  public static final class string {
    public static final int download_add=1;
    public static final int download_delete=2;
    public static final int search_hint=3;
  }
  public static final class dimen {
    public static final int edge_gesture_dp=1;
  }
}
