package android;
public final class R {
  public static final class attr { public static final int selectableItemBackground=0x0101038f; }
  public static final class id { public static final int content=0x01020002; }
  public static final class layout { public static final int simple_spinner_item=0x01090000; public static final int simple_spinner_dropdown_item=0x01090001; }
  public static final class color { public static final int black=0x01020000, white=0x01020001; }
  public static final class drawable { public static final int stat_sys_download=0x0108005a; }
}
