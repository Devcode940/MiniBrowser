package android.net;
public class ConnectivityManager {
  public void registerNetworkCallback(NetworkRequest r,NetworkCallback c){}
  public void unregisterNetworkCallback(NetworkCallback c){}
  public Network getActiveNetwork(){ return null; }
  public NetworkCapabilities getNetworkCapabilities(Network n){ return null; }
  public static abstract class NetworkCallback { public void onCapabilitiesChanged(Network n,NetworkCapabilities c){} }
}
