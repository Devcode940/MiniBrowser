package android.net;
public class NetworkCapabilities {
  public static final int NET_CAPABILITY_INTERNET=0, TRANSPORT_CELLULAR=0, TRANSPORT_WIFI=1;
  public boolean hasTransport(int t){ return false; }
}
