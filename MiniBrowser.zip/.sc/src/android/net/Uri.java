package android.net;
import java.io.File;
public class Uri {
  public static Uri parse(String s){ return null; }
  public static Uri fromFile(File f){ return null; }
  public String getHost(){ return null; }
  public String getPath(){ return null; }
  public String getScheme(){ return null; }
  public String toString(){ return null; }
}
