package android.net;
public class NetworkRequest { public static class Builder { public Builder addCapability(int c){ return this; } public NetworkRequest build(){ return null; } } }
