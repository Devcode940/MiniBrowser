package android.os;
public class Bundle { public void putString(String k,String v){} public String getString(String k,String d){ return d; } public String getString(String k){ return null; } }
