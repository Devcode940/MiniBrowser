package android.os;
public class Build {
  public static class VERSION { public static int SDK_INT; }
  public static class VERSION_CODES { public static final int N=24, O=26; }
}
