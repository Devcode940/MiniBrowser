package android.widget; import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup;
public abstract class AdapterView<T> extends ViewGroup {
  public AdapterView(Context c){ super(c); } public AdapterView(Context c,AttributeSet a){ super(c,a); }
  public interface OnItemSelectedListener { void onItemSelected(AdapterView<?> p,android.view.View v,int pos,long idl); void onNothingSelected(AdapterView<?> p); }
  public interface Adapter {}
  public interface SpinnerAdapter extends Adapter {}
}
