package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ViewFlipper extends ViewAnimator { public ViewFlipper(Context c){ super(c); } public ViewFlipper(Context c,AttributeSet a){ super(c,a); } }
