package android.widget; import android.content.Context; import android.util.AttributeSet;
public abstract class CompoundButton extends Button {
  public CompoundButton(Context c){ super(c); } public CompoundButton(Context c,AttributeSet a){ super(c,a); }
  public void setChecked(boolean c){} public void setOnCheckedChangeListener(OnCheckedChangeListener l){}
  public interface OnCheckedChangeListener { void onCheckedChanged(CompoundButton b,boolean c); }
}
