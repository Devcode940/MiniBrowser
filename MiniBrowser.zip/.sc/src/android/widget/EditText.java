package android.widget;
import android.content.Context; import android.text.Editable; import android.text.TextWatcher; import android.util.AttributeSet;
public class EditText extends TextView {
  public EditText(Context c){ super(c); } public EditText(Context c,AttributeSet a){ super(c,a); }
  public Editable getText(){ return null; } public void addTextChangedListener(TextWatcher w){}
}
