package android.widget; import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup;
public class FrameLayout extends ViewGroup {
  public FrameLayout(Context c){ super(c); } public FrameLayout(Context c,AttributeSet a){ super(c,a); }
  public static class LayoutParams extends MarginLayoutParams { public int gravity; public LayoutParams(int w,int h){ super(w,h); } }
}
