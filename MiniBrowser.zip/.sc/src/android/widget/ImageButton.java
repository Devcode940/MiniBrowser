package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ImageButton extends ImageView { public ImageButton(Context c){ super(c); } public ImageButton(Context c,AttributeSet a){ super(c,a); } }
