package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ImageView extends android.view.View {
  public ImageView(Context c){ super(c); } public ImageView(Context c,AttributeSet a){ super(c,a); }
  public void setImageResource(int r){} public enum ScaleType { CENTER } public void setScaleType(ScaleType t){}
}
