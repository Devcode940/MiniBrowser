package android.widget; import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup;
public class GridLayout extends ViewGroup {
  public GridLayout(Context c){ super(c); } public GridLayout(Context c,AttributeSet a){ super(c,a); }
  public static final int UNDEFINED=Integer.MIN_VALUE;
  public static Spec spec(int s,int sz,float w){ return null; } public static Spec spec(int s,int sz){ return null; } public static Spec spec(int sz){ return null; }
  public static class Spec {}
  public static class LayoutParams extends MarginLayoutParams { public Spec rowSpec, columnSpec; public LayoutParams(){} public LayoutParams(int w,int h){ super(w,h); } public void setGravity(int g){} }
}
