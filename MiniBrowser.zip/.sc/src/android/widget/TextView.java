package android.widget;
import android.content.Context;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
public class TextView extends android.view.View {
  public TextView(Context c){ super(c); } public TextView(Context c,AttributeSet a){ super(c,a); }
  public void setText(CharSequence t){} public void setText(String t){}
  public void setTextColor(int c){} public void setTextSize(int u,float s){}
  public void setGravity(int g){} public void setTypeface(Typeface t){}
  public void setSingleLine(boolean s){} public void setHint(int r){} public void setHint(CharSequence h){}
  public void setSelection(int i){} public void selectAll(){} public void setInputType(int t){}
  public void setMinLines(int n){} public void setEllipsize(TextUtils.TruncateAt w){}
  public void setMarqueeRepeatLimit(int n){} public void setSelected(boolean s){}
  public void setImeOptions(int o){} public void setHintTextColor(int c){} public void setMaxLines(int n){}
  public void setOnEditorActionListener(OnEditorActionListener l){}
  public interface OnEditorActionListener { boolean onEditorAction(TextView v,int a,KeyEvent e); }
}
