package android.widget; import android.content.Context;
public class Toast { public static final int LENGTH_SHORT=0; public static Toast makeText(Context c,CharSequence t,int d){ return null; } public void show(){} }
