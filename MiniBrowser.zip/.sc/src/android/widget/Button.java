package android.widget; import android.content.Context; import android.util.AttributeSet;
public class Button extends TextView { public Button(Context c){ super(c); } public Button(Context c,AttributeSet a){ super(c,a); } public void setOnClickListener(android.view.View.OnClickListener l){} }
