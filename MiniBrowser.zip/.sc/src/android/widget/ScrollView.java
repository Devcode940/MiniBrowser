package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ScrollView extends FrameLayout {
  public ScrollView(Context c){ super(c); } public ScrollView(Context c,AttributeSet a){ super(c,a); }
  public void fullScroll(int d){}
}
