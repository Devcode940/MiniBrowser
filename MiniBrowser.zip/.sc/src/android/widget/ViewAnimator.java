package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ViewAnimator extends FrameLayout {
  public ViewAnimator(Context c){ super(c); } public ViewAnimator(Context c,AttributeSet a){ super(c,a); }
  public void setDisplayedChild(int i){} public int getDisplayedChild(){ return 0; }
}
