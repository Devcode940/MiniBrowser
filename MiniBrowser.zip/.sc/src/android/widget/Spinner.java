package android.widget; import android.content.Context; import android.util.AttributeSet;
public class Spinner extends AdapterView {
  public Spinner(Context c){ super(c); } public Spinner(Context c,AttributeSet a){ super(c,a); }
  public void setAdapter(SpinnerAdapter a){} public void setSelection(int i){} public int getSelection(){ return 0; }
  public void setOnItemSelectedListener(OnItemSelectedListener l){}
}
