package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ProgressBar extends android.view.View {
  public ProgressBar(Context c){ super(c); } public ProgressBar(Context c,AttributeSet a){ super(c,a); }
  public void setProgress(int p){} public void setMax(int m){} public void setIndeterminate(boolean b){}
}
