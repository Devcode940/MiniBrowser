package android.widget; import android.content.Context;
public class CheckBox extends CompoundButton { public CheckBox(Context c){ super(c); } public void setText(CharSequence t){} }
