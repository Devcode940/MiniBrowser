package android.widget; import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup;
public class LinearLayout extends ViewGroup {
  public LinearLayout(Context c){ super(c); } public LinearLayout(Context c,AttributeSet a){ super(c,a); }
  public static final int VERTICAL=1, HORIZONTAL=0;
  public void setOrientation(int o){} public void setGravity(int g){}
  public static class LayoutParams extends MarginLayoutParams { public float weight; public int gravity; public LayoutParams(int w,int h){ super(w,h); } public LayoutParams(int w,int h,float ww){ super(w,h); weight=ww; } }
}
