package android.widget; import android.content.Context; import java.util.List;
public class ArrayAdapter<T> implements AdapterView.SpinnerAdapter {
  public ArrayAdapter(Context c,int r,T[] o){} public ArrayAdapter(Context c,int r,List<T> o){}
  public void setDropDownViewResource(int r){}
}
