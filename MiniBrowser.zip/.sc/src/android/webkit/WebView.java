package android.webkit;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.AttributeSet;
public class WebView extends android.view.ViewGroup {
  public WebView(Context c){ super(c); } public WebView(Context c,AttributeSet a){ super(c,a); } public WebView(Context c,AttributeSet a,int d){ super(c,a,d); }
  public WebSettings getSettings(){ return null; }
  public void setWebViewClient(WebViewClient c){} public void setWebChromeClient(WebChromeClient c){}
  public void addJavascriptInterface(Object o,String n){} public void removeJavascriptInterface(String n){}
  public void loadUrl(String u){} public void evaluateJavascript(String j,ValueCallback<String> c){}
  public boolean canGoBack(){ return false; } public boolean canGoForward(){ return false; }
  public void goBack(){} public void goForward(){} public void reload(){} public void stopLoading(){}
  public String getUrl(){ return null; }
  public void clearCache(boolean b){} public void clearHistory(){} public void clearFormData(){} public void destroy(){}
  public WebBackForwardList saveState(Bundle b){ return null; } public WebBackForwardList restoreState(Bundle b){ return null; }
  public void setHorizontalScrollBarEnabled(boolean b){}
  public boolean onTouchEvent(android.view.MotionEvent e){ return false; }
  protected void onScrollChanged(int l,int t,int ol,int ot){}
}
