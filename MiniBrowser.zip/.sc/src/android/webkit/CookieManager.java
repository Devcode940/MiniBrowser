package android.webkit;
public class CookieManager {
  public static CookieManager getInstance(){ return null; }
  public void setAcceptCookie(boolean a){} public void setAcceptThirdPartyCookies(WebView v,boolean a){}
  public void flush(){} public void removeAllCookies(ValueCallback<Boolean> c){}
}
