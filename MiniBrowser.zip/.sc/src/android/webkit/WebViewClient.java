package android.webkit;
import android.graphics.Bitmap;
public class WebViewClient {
  public void onPageStarted(WebView v,String u,Bitmap f){} public void onPageFinished(WebView v,String u){}
  public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){ return null; }
  public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){ return false; }
  public void onReceivedSslError(WebView v,SslErrorHandler h,SslError e){}
  public void onSafeBrowsingHit(WebView v,WebResourceRequest r,int t,SafeBrowsingResponse s){}
}
