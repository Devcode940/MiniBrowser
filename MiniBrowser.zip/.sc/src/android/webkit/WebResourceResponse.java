package android.webkit;
import java.io.InputStream;
public class WebResourceResponse { public WebResourceResponse(String m,String e,InputStream d){} }
