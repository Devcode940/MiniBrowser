package android.webkit; public class URLUtil { public static boolean isNetworkUrl(String u){ return false; } }
