package android.webkit; public class SafeBrowsingResponse { public void backToSafety(boolean b){} public void proceed(boolean b){} }
