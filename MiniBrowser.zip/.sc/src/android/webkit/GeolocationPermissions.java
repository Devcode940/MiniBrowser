package android.webkit; public class GeolocationPermissions { public interface Callback { void invoke(String o,boolean a,boolean r); } }
