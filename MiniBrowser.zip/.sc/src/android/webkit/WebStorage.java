package android.webkit; public class WebStorage { public static WebStorage getInstance(){ return null; } public void deleteAllData(){} }
