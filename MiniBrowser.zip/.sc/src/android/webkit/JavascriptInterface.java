package android.webkit;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) public @interface JavascriptInterface {}
