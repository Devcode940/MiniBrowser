package android.webkit;
public class WebSettings {
  public static final int MIXED_CONTENT_NEVER_ALLOW=1, MIXED_CONTENT_COMPATIBILITY_MODE=2, LOAD_DEFAULT=0, LOAD_CACHE_ELSE_NETWORK=1;
  public static final class LayoutAlgorithm { public static final LayoutAlgorithm NORMAL = new LayoutAlgorithm(); }
  public void setJavaScriptEnabled(boolean b){} public void setDomStorageEnabled(boolean b){} public void setDatabaseEnabled(boolean b){}
  public void setSupportZoom(boolean b){} public void setBuiltInZoomControls(boolean b){} public void setDisplayZoomControls(boolean b){}
  public void setLoadWithOverviewMode(boolean b){} public void setUseWideViewPort(boolean b){} public void setTextZoom(int z){}
  public void setMediaPlaybackRequiresUserGesture(boolean b){} public void setAllowFileAccess(boolean b){}
  public void setAllowFileAccessFromFileURLs(boolean b){} public void setAllowUniversalAccessFromFileURLs(boolean b){}
  public void setMixedContentMode(int m){} public void setJavaScriptCanOpenWindowsAutomatically(boolean b){}
  public void setSupportMultipleWindows(boolean b){} public void setGeolocationEnabled(boolean b){}
  public void setCacheMode(int m){} public void setBlockNetworkImage(boolean b){} public void setLayoutAlgorithm(LayoutAlgorithm a){}
  public void setSafeBrowsingEnabled(boolean b){} public void setUserAgentString(String u){} public String getUserAgentString(){ return null; }
}
