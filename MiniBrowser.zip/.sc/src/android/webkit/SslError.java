package android.webkit; public class SslError {}
