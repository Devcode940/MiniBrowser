package android.webkit;
public class PermissionRequest {
  public static final String RESOURCE_VIDEO_CAPTURE="v", RESOURCE_AUDIO_CAPTURE="a";
  public String[] getResources(){ return null; } public void grant(String[] r){} public void deny(){}
}
