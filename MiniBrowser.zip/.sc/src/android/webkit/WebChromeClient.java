package android.webkit;
import android.content.Intent;
public class WebChromeClient {
  public void onProgressChanged(WebView v,int p){} public void onReceivedTitle(WebView v,String t){}
  public void onGeolocationPermissionsShowPrompt(String o,GeolocationPermissions.Callback c){}
  public void onPermissionRequest(PermissionRequest r){}
  public boolean onShowFileChooser(WebView v,ValueCallback<android.net.Uri[]> c,FileChooserParams p){ return false; }
  public void onConsoleMessage(String m,int l,String s){}
  public static abstract class FileChooserParams { public Intent createIntent(){ return null; } }
}
