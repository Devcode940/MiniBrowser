package android.view.inputmethod;
import android.view.IBinder;
public class InputMethodManager { public void hideSoftInputFromWindow(IBinder t,int f){} }
