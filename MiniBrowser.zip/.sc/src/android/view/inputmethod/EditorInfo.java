package android.view.inputmethod;
public class EditorInfo { public static final int IME_ACTION_GO=2, IME_ACTION_SEARCH=3, IME_ACTION_DONE=6, IME_ACTION_SEND=4; }
