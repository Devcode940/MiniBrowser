package android.view;
public abstract class Window {
  public void setBackgroundDrawableResource(int r){}
  public View getDecorView(){ return null; }
}
