package android.view;
public class Gravity { public static final int CENTER_HORIZONTAL=1, CENTER_VERTICAL=2, CENTER=0x11, START=0x800003, END=0x800005, BOTTOM=0x50, TOP=0x30; }
