package android.view;
import android.content.Context;
public abstract class LayoutInflater {
  public static LayoutInflater from(Context c){ return null; }
  public View inflate(int r,ViewGroup root,boolean a){ return null; }
  public View inflate(int r,ViewGroup root){ return null; }
}
