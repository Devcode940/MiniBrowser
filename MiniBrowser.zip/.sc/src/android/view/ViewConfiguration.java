package android.view;
import android.content.Context;
public class ViewConfiguration { public static ViewConfiguration get(Context c){ return null; } public int getScaledTouchSlop(){ return 0; } }
