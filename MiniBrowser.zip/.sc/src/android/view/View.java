package android.view;
import android.content.Context;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
public class View {
  public static final int VISIBLE=0, GONE=8, LAYER_TYPE_HARDWARE=2, OVER_SCROLL_NEVER=2, FOCUS_DOWN=130;
  public View(Context c){} public View(Context c,AttributeSet a){} public View(Context c,AttributeSet a,int d){}
  public void setLayoutParams(ViewGroup.LayoutParams p){}
  public ViewGroup.LayoutParams getLayoutParams(){ return null; }
  public void setOnClickListener(OnClickListener l){}
  public void setOnLongClickListener(OnLongClickListener l){}
  public void setOnFocusChangeListener(OnFocusChangeListener l){}
  public void setBackground(Drawable d){}
  public void setBackgroundResource(int id){}
  public void setPadding(int a,int b,int c,int d){}
  public void setClickable(boolean c){}
  public void setVisibility(int v){}
  public void setEnabled(boolean e){}
  public void setAlpha(float a){}
  public void setRotation(float r){}
  public void setContentDescription(CharSequence c){}
  public void setScaleX(float x){}
  public void setScaleY(float y){}
  public void setVerticalScrollBarEnabled(boolean b){}
  public void setOverScrollMode(int m){}
  public void setBackgroundColor(int c){}
  public void setTranslationY(float v){}
  public void setTranslationX(float v){}
  public void setElevation(float e){}
  public int getWidth(){ return 0; } public int getHeight(){ return 0; }
  public int getMeasuredHeight(){ return 0; } public int getMeasuredWidth(){ return 0; }
  public float getX(){ return 0f; } public float getY(){ return 0f; }
  public void setX(float x){} public void setY(float y){}
  public ViewParent getParent(){ return null; }
  public IBinder getWindowToken(){ return null; }
  public boolean performHapticFeedback(int c){ return false; }
  public void setLayerType(int l,Paint p){}
  public void requestLayout(){}
  public void measure(int ws,int hs){}
  public Context getContext(){ return null; }
  public <T extends View> T findViewById(int id){ return null; }
  public void post(Runnable r){}
  public boolean setOnTouchListener(OnTouchListener l){ return true; }
  public int getVisibility(){ return 0; }
  public android.view.ViewPropertyAnimator animate(){ return null; }
  public boolean requestFocus(){ return true; }
  public interface OnClickListener { void onClick(View v); }
  public interface OnFocusChangeListener { void onFocusChange(View v,boolean h); }
  public interface OnLongClickListener { boolean onLongClick(View v); }
  public interface OnTouchListener { boolean onTouch(View v,MotionEvent e); }
  public static final class MeasureSpec { public static final int EXACTLY=0x40000000, UNSPECIFIED=0; public static int makeMeasureSpec(int s,int m){ return 0; } }
}
