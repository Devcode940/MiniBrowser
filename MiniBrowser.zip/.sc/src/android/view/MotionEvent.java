package android.view;
public class MotionEvent {
  public static final int ACTION_DOWN=0, ACTION_UP=1, ACTION_MOVE=2, ACTION_CANCEL=3;
  public int getActionMasked(){ return 0; }
  public float getX(){ return 0f; } public float getY(){ return 0f; }
  public float getRawX(){ return 0f; } public float getRawY(){ return 0f; }
  public long getEventTime(){ return 0L; } public int getActionIndex(){ return 0; }
}
