package android.view;
import android.content.Context;
import android.util.AttributeSet;
public abstract class ViewGroup extends View {
  public ViewGroup(Context c){ super(c); } public ViewGroup(Context c,AttributeSet a){ super(c,a); } public ViewGroup(Context c,AttributeSet a,int d){ super(c,a,d); }
  public void removeView(View v){}
  public int getChildCount(){ return 0; }
  public View getChildAt(int i){ return null; }
  public void addView(View v){}
  public void addView(View v,int index){}
  public void removeViewAt(int i){}
  public void removeAllViews(){}
  public static class LayoutParams { public static final int MATCH_PARENT=-1, WRAP_CONTENT=-2; public int width, height; public LayoutParams(int w,int h){} public LayoutParams(){} }
  public static class MarginLayoutParams extends LayoutParams { public int topMargin,bottomMargin,leftMargin,rightMargin; public MarginLayoutParams(){} public MarginLayoutParams(int w,int h){ super(w,h); } public void setMargins(int a,int b,int c,int d){} }
}
