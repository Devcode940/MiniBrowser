package android.view;
public class ViewPropertyAnimator {
  public ViewPropertyAnimator translationY(float v){ return this; }
  public ViewPropertyAnimator translationX(float v){ return this; }
  public ViewPropertyAnimator alpha(float v){ return this; }
  public ViewPropertyAnimator scaleX(float v){ return this; }
  public ViewPropertyAnimator scaleY(float v){ return this; }
  public ViewPropertyAnimator setDuration(long d){ return this; }
  public ViewPropertyAnimator start(){ return this; }
  public ViewPropertyAnimator withEndAction(Runnable r){ return this; }
}
