package android.graphics.drawable;
public class GradientDrawable extends Drawable { public void setColor(int c){} public void setCornerRadius(float r){} public void setStroke(int w,int c){} }
