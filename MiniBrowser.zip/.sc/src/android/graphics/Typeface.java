package android.graphics;
public class Typeface {
  public static Typeface DEFAULT, DEFAULT_BOLD, MONOSPACE;
  public static final int BOLD=1;
  public static Typeface create(Typeface f,int s){ return null; }
}
