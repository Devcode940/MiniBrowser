package android;
public class Manifest { public static final class permission {
  public static final String CAMERA="c", RECORD_AUDIO="r", ACCESS_FINE_LOCATION="fl", ACCESS_COARSE_LOCATION="cl";
}}
