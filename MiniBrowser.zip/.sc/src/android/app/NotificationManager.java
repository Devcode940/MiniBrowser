package android.app;
public interface NotificationManager {
  int IMPORTANCE_LOW=2;
  void notify(int id,Notification n); void cancel(int id);
  void createNotificationChannel(NotificationChannel c);
}
