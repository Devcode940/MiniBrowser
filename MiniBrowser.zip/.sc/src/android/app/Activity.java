package android.app;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
public class Activity extends Context {
  public static final int RESULT_OK=-1, RESULT_CANCELED=0;
  protected void onCreate(Bundle b){}
  protected void onStart(){} protected void onResume(){} protected void onPause(){}
  protected void onStop(){} protected void onDestroy(){}
  protected void onSaveInstanceState(Bundle b){}
  public void onBackPressed(){}
  public void setContentView(int id){}
  public <T extends android.view.View> T findViewById(int id){ return null; }
  public void requestPermissions(String[] p,int c){}
  public void startActivityForResult(Intent i,int c){}
  public void runOnUiThread(Runnable r){}
  public void finish(){}
  public Intent getIntent(){ return null; }
  public boolean isFinishing(){ return false; }
  public void onRequestPermissionsResult(int rc,String[] p,int[] g){}
  protected void onActivityResult(int rc,int rr,Intent d){}
  public SharedPreferences getPreferences(int m){ return null; }
  public void startActivity(Intent i){}
  public android.content.res.Resources.Theme getTheme(){ return null; }
  public android.view.Window getWindow(){ return null; }
  public boolean isInPictureInPictureMode(){ return false; }
  public void enterPictureInPictureMode(PictureInPictureParams p){}
  protected void onUserLeaveHint(){}
  public void onPictureInPictureModeChanged(boolean ip, android.content.res.Configuration c){}
  public boolean moveTaskToBack(boolean n){ return false; }
}
