package android.app;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
public class AlertDialog {
  public static final int BUTTON_NEUTRAL=-3, BUTTON_POSITIVE=-1, BUTTON_NEGATIVE=-2;
  public static class Builder {
    public Builder(Context c){}
    public Builder setTitle(CharSequence t){ return this; }
    public Builder setTitle(int r){ return this; }
    public Builder setMessage(CharSequence m){ return this; }
    public Builder setSingleChoiceItems(String[] i,int c,DialogInterface.OnClickListener l){ return this; }
    public Builder setItems(String[] i,DialogInterface.OnClickListener l){ return this; }
    public Builder setPositiveButton(CharSequence t,DialogInterface.OnClickListener l){ return this; }
    public Builder setNeutralButton(CharSequence t,DialogInterface.OnClickListener l){ return this; }
    public Builder setNegativeButton(CharSequence t,DialogInterface.OnClickListener l){ return this; }
    public Builder setView(View v){ return this; }
    public AlertDialog create(){ return new AlertDialog(); }
    public void show(){}
  }
  public AlertDialog(){}
  public void show(){}
  public void dismiss(){}
  public android.widget.Button getButton(int w){ return null; }
  public View findViewById(int id){ return null; }
}
