package android.app;
import android.content.Context;
import android.content.Intent;
public class PendingIntent {
  public static final int FLAG_UPDATE_CURRENT=0x8000000, FLAG_IMMUTABLE=0x04000000, FLAG_MUTABLE=0x02000000;
  public static PendingIntent getActivity(Context c,int code,Intent i,int f){ return null; }
}
