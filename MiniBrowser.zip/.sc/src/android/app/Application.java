package android.app;
import android.content.Context;
public abstract class Application extends Context { public void onCreate(){} }
