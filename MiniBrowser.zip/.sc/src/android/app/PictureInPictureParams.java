package android.app;
public final class PictureInPictureParams {
  public static final class Builder {
    public Builder setAspectRatio(android.util.Rational r){ return this; }
    public PictureInPictureParams build(){ return null; }
  }
}
