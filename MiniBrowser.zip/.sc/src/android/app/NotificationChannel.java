package android.app;
public class NotificationChannel {
  public NotificationChannel(String id,CharSequence n,int i){}
  public void setDescription(String s){} public void setShowBadge(boolean b){}
}
