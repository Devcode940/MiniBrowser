package android.content;
import android.net.Uri;
public class Intent {
  public static final String ACTION_MAIN="m", ACTION_VIEW="v", ACTION_SEND="s";
  public static final int FLAG_ACTIVITY_NEW_TASK=0, FLAG_GRANT_READ_URI_PERMISSION=0, FLAG_ACTIVITY_CLEAR_TOP=0;
  public static final String EXTRA_TEXT="t", EXTRA_STREAM="st";
  public Intent(){} public Intent(Context c,Class<?> cls){} public Intent(String a){} public Intent(String a,Uri u){}
  public Intent putExtra(String k,String v){ return this; }
  public Intent putExtra(String k,Uri v){ return this; }
  public Intent setType(String t){ return this; }
  public Intent setDataAndType(Uri u,String t){ return this; }
  public Intent addFlags(int f){ return this; }
  public static Intent createChooser(Intent t,CharSequence s){ return null; }
  public String getStringExtra(String n){ return null; }
  public String getDataString(){ return null; }
  public ClipData getClipData(){ return null; }
  public Uri getData(){ return null; }
  public String getType(){ return null; }
}
