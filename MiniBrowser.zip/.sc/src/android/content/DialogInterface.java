package android.content;
public interface DialogInterface {
  public static final int BUTTON_NEUTRAL=-3;
  void dismiss();
  interface OnClickListener { void onClick(DialogInterface d,int w); }
}
