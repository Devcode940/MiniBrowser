package android.content;
import android.net.Uri;
public class ClipData {
  public static ClipData newPlainText(CharSequence l,CharSequence t){ return null; }
  public int getItemCount(){ return 0; }
  public Item getItemAt(int i){ return null; }
  public static class Item { public Uri getUri(){ return null; } }
}
