package android.content;
import android.content.res.AssetManager;
import android.content.res.Resources;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
public abstract class Context {
  public static final int MODE_PRIVATE=0, MODE_APPEND=0x8000;
  public static final String CONNECTIVITY_SERVICE="c", CLIPBOARD_SERVICE="cb", INPUT_METHOD_SERVICE="im", NOTIFICATION_SERVICE="n";
  public Resources getResources(){ return null; }
  public File getFilesDir(){ return null; }
  public File getExternalFilesDir(String t){ return null; }
  public AssetManager getAssets(){ return null; }
  public Object getSystemService(String n){ return null; }
  public <T> T getSystemService(Class<T> s){ return null; }
  public String getPackageName(){ return null; }
  public FileOutputStream openFileOutput(String n,int m) throws IOException { return null; }
  public int checkCallingOrSelfPermission(String p){ return 0; }
  public int getColor(int id){ return 0; }
  public SharedPreferences getSharedPreferences(String n,int m){ return null; }
  public Context getApplicationContext(){ return this; }
}
