package android.content;
public class ClipboardManager { public void setPrimaryClip(ClipData c){} }
