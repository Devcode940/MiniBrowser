package android.content.res;
import java.io.IOException; import java.io.InputStream;
public class AssetManager { public InputStream open(String n) throws IOException { return null; } }
