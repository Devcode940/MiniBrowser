package android.content.res;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
public class Resources {
  public DisplayMetrics getDisplayMetrics(){ return null; }
  public float getDimension(int id){ return 0f; }
  public int getIdentifier(String n,String t,String p){ return 0; }
  public Drawable getDrawable(int id){ return null; }
  public static class Theme { public boolean resolveAttribute(int a,android.util.TypedValue o,boolean r){ return false; } }
}
