package android.content.pm;
public class PackageManager { public static final int PERMISSION_GRANTED=0; }
