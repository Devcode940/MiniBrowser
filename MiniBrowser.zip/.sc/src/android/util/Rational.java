package android.util; public class Rational { public Rational(int w,int h){} }
