package android.util; public class DisplayMetrics { public float density; public int widthPixels, heightPixels; }
