package android.util;
public class TypedValue {
  public int resourceId;
  public static final int COMPLEX_UNIT_SP=2, COMPLEX_UNIT_DIP=1;
  public static float applyDimension(int u,float v,DisplayMetrics m){ return 0f; }
}
