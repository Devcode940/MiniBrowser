#!/usr/bin/env bash
# ============================================================================
#  MiniBrowser v16 — atomic Termux CLI build (NO Gradle, NO AndroidX)
#
#  Pipeline:
#     clean -> aapt2 compile -> aapt2 link (+R.java +assets) -> javac
#          -> d8 (dex) -> merge classes.dex -> jarsigner (v1) -> zipalign
#          -> (apksigner v2 overlay, if available, for Android 11+ install)
#
#  Usage:   bash build.sh            # full build
#           bash build.sh clean      # remove build/ only
#           bash build.sh run        # build then `adb install -r`
#  Requires: aapt2, d8, zipalign, jarsigner, keytool, javac  (openjdk-17, zip)
# ============================================================================
set -euo pipefail

# ----------------------------- config ---------------------------------------
APP_NAME="MiniBrowser"
PKG="com.minibrowser"
VERSION_CODE=16
VERSION_NAME="v16"
MIN_SDK=24
TARGET_SDK=34

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$ROOT/app/src/main"
BUILD="$ROOT/build"
GEN="$BUILD/gen"
OBJ="$BUILD/obj"
DEX="$BUILD/dex"
OUT="$BUILD/out"

# Debug signing material (auto-created on first build).
KS="${KEYSTORE:-$ROOT/debug.keystore}"
KS_PASS="${KEYSTORE_PASS:-android}"
ALIAS="${KEYSTORE_ALIAS:-minibrowser}"

FINAL_APK="$BUILD/${APP_NAME}-${VERSION_NAME}.apk"

# ------------------------- locate the Android SDK ---------------------------
detect_android_home() {
    for cand in "$ANDROID_HOME" "$ANDROID_SDK_ROOT" \
                "$HOME/android-sdk" "$HOME/Android/Sdk" \
                "/data/data/com.termux/files/home/android-sdk" \
                "$PREFIX/share/android-sdk"; do
        [ -n "$cand" ] && [ -d "$cand" ] && { echo "$cand"; return 0; }
    done
    return 1
}

if ! AH="$(detect_android_home)"; then
    echo "ERROR: Android SDK not found."
    echo "  export ANDROID_HOME=/path/to/sdk   (must contain build-tools/ and platforms/)"
    exit 1
fi
echo ">> SDK: $AH"

# Newest build-tools + platform available (prefer android-34 / bt 34.x).
BT="$(ls -d "$AH/build-tools"/* 2>/dev/null | sort -V | tail -n1)" || true
PLAT="$(ls -d "$AH/platforms"/android-34 2>/dev/null | head -n1)"
[ -z "$PLAT" ] && PLAT="$(ls -d "$AH/platforms"/android-* 2>/dev/null | sort -V | tail -n1)"
ANDROID_JAR="$PLAT/android.jar"
[ -z "$BT" ] && { echo "ERROR: no build-tools under $AH/build-tools"; exit 1; }
[ -f "$ANDROID_JAR" ] || { echo "ERROR: android.jar not found at $ANDROID_JAR"; exit 1; }

AAPT2="$BT/aapt2"
D8="$BT/d8"
ZIPALIGN="$BT/zipalign"
APKSIGNER="$BT/apksigner"
echo ">> build-tools: $BT"
echo ">> platform:    $PLAT"

for tool in aapt2 d8 zipalign jarsigner keytool javac zip; do
    case "$tool" in
        aapt2)        T="$AAPT2" ;;
        d8)           T="$D8" ;;
        zipalign)     T="$ZIPALIGN" ;;
        *)            T="$tool" ;;
    esac
    if ! command -v "$T" >/dev/null 2>&1 && [ ! -x "$T" ]; then
        echo "ERROR: required tool not found: $tool"
        exit 1
    fi
done
# apksigner is OPTIONAL (v2 hardening for Android 11+). Not every build-tools ships it.
if { [ -x "$APKSIGNER" ] || command -v "$APKSIGNER" >/dev/null 2>&1; }; then
    echo ">> apksigner: available (v2 hardening will run)"
else
    echo ">> apksigner: NOT found (v1-only fallback)"
fi

# ------------------------------- helpers ------------------------------------
hr() { printf '\n\033[1;36m== %s ==\033[0m\n' "$*"; }

# ------------------------------- clean --------------------------------------
do_clean() {
    hr "Clean"
    rm -rf "$BUILD"
    echo "   removed $BUILD"
}

if [ "${1:-}" = "clean" ]; then do_clean; exit 0; fi

# ------------------------------- build --------------------------------------
mkdir -p "$GEN" "$OBJ" "$DEX" "$OUT"

# 1) Compile resources -> flat zip
hr "1/8  aapt2 compile"
RES_ZIP="$BUILD/res-compiled.zip"
rm -f "$RES_ZIP"
"$AAPT2" compile --dir "$SRC/res" -o "$RES_ZIP"
echo "   $(unzip -l "$RES_ZIP" | tail -n1 | awk '{print $2}') compiled entries"

# 2) Link: manifest + compiled res + assets -> unsigned APK, and emit R.java
hr "2/8  aapt2 link"
UNSIGNED="$BUILD/unsigned.apk"
rm -f "$UNSIGNED"
"$AAPT2" link \
    -I "$ANDROID_JAR" \
    --manifest "$SRC/AndroidManifest.xml" \
    -A "$SRC/assets" \
    --java "$GEN" \
    --min-sdk-version "$MIN_SDK" \
    --target-sdk-version "$TARGET_SDK" \
    --version-code "$VERSION_CODE" \
    --version-name "$VERSION_NAME" \
    -o "$UNSIGNED" \
    "$RES_ZIP"
echo "   resources + manifest linked -> $(basename "$UNSIGNED")"

# 3) Compile Java (R.java + sources) against android.jar
hr "3/8  javac"
JAVA_FILES=()
while IFS= read -r f; do JAVA_FILES+=("$f"); done < <(find "$SRC/java" -name '*.java' -print)
javac -nowarn -encoding UTF-8 -source 1.8 -target 1.8 \
      -bootclasspath "$ANDROID_JAR" \
      -classpath "$ANDROID_JAR" \
      -d "$OBJ" \
      "$GEN/com/minibrowser/R.java" \
      "${JAVA_FILES[@]}"
CLASS_COUNT=$(find "$OBJ" -name '*.class' | wc -l | tr -d ' ')
echo "   $CLASS_COUNT .class files compiled"

# 4) Dex with d8 (desugaring, min-api 24)
hr "4/8  d8"
rm -f "$DEX/classes.dex"
"$D8" --release --min-api "$MIN_SDK" --lib "$ANDROID_JAR" \
      --output "$DEX" \
      $(find "$OBJ" -name '*.class')
echo "   classes.dex -> $(du -h "$DEX/classes.dex" | cut -f1)"

# 5) Merge classes.dex into the APK (at archive root)
hr "5/8  merge dex"
( cd "$DEX" && zip -g -q -X "$UNSIGNED" classes.dex )
echo "   dex merged into APK"

# 6) Create / reuse a debug keystore
hr "6/8  keystore"
if [ ! -f "$KS" ]; then
    keytool -genkeypair -v -keystore "$KS" -storepass "$KS_PASS" -alias "$ALIAS" \
            -keyalg RSA -keysize 2048 -validity 10000 \
            -dname "CN=MiniBrowser, OU=Dev, O=MiniBrowser, L=Karuri, ST=Muranga, C=KE" \
            >/dev/null 2>&1
    echo "   created $KS"
else
    echo "   reusing $KS"
fi

# 7) Sign with jarsigner (v1 — per spec)
hr "7/8  jarsigner (v1)"
jarsigner -sigalg SHA256withRSA -digestalg SHA-256 \
          -keystore "$KS" -storepass "$KS_PASS" \
          "$UNSIGNED" "$ALIAS" >/dev/null
echo "   v1 signature applied"

# 8) Zip-align (MUST follow jarsigner for v1)
hr "8/8  zipalign"
SIGNED="$BUILD/signed.apk"
"$ZIPALIGN" -f -p 4 "$UNSIGNED" "$SIGNED"
echo "   aligned -> 4-byte boundary"

# Optional hardening: overlay a v2 signature so the APK installs on Android 11+
# (targetSdk 34 requires v2+). apksigner preserves the zipalign we just did.
APK="$SIGNED"
if [ -x "$APKSIGNER" ] || command -v "$APKSIGNER" >/dev/null 2>&1; then
    hr "v2 hardening (apksigner)"
    "$APKSIGNER" sign --ks "$KS" --ks-pass "pass:$KS_PASS" \
        --v1-signing-enabled true --v2-signing-enabled true \
        --out "$FINAL_APK" "$SIGNED" >/dev/null
    echo "   v1+v2 signature applied"
else
    echo ">> apksigner not found — keeping v1-only (may not install on Android 11+)"
    cp "$SIGNED" "$FINAL_APK"
fi

# Verify
if [ -x "$APKSIGNER" ] || command -v "$APKSIGNER" >/dev/null 2>&1; then
    "$APKSIGNER" verify --print-certs "$FINAL_APK" >/dev/null 2>&1 \
        && echo "   signature verified OK"
fi

# -------------------------------- size check --------------------------------
hr "RESULT"
SIZE_BYTES=$(wc -c < "$FINAL_APK")
SIZE_KB=$(( SIZE_BYTES / 1024 ))
SIZE_MB=$(( SIZE_BYTES / 1024 / 1024 ))
printf '   APK : %s\n   Size : %d KB (%d.%d MB)\n' \
       "$FINAL_APK" "$SIZE_KB" "$SIZE_MB" $(( (SIZE_BYTES % 1048576) * 10 / 1048576 ))
if [ "$SIZE_BYTES" -gt 10485760 ]; then
    echo "   ⚠  EXCEEDS 10 MB target"
else
    echo "   ✔  under 10 MB target"
fi

if [ "${1:-}" = "run" ]; then
    hr "adb install"
    adb install -r "$FINAL_APK" && adb shell am start -n "$PKG/.MainActivity"
fi
