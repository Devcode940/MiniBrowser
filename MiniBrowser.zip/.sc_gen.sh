#!/usr/bin/env bash
# Regenerates a minimal Android/AndroidX stub tree (for offline type-checking)
# and a com/minibrowser/R.java derived from actual source references, then
# compiles the whole project against them. NOT part of the shipped app — this
# is a scratch harness to verify the Java compiles before a real Gradle build.
set -e
SC=/home/user/.sc
SRC=$SC/src
OUT=$SC/out
rm -rf "$SC" && mkdir -p "$SRC/com/minibrowser"

cd "$SRC"

# --------------------------- platform + androidx stubs ---------------------------
mkd(){ mkdir -p "$(dirname "$1")"; }

w(){ mkd "$1"; cat > "$1"; }

w android/app/Activity.java <<'EOF'
package android.app;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
public class Activity extends Context {
  public static final int RESULT_OK=-1, RESULT_CANCELED=0;
  protected void onCreate(Bundle b){}
  protected void onStart(){} protected void onResume(){} protected void onPause(){}
  protected void onStop(){} protected void onDestroy(){}
  protected void onSaveInstanceState(Bundle b){}
  public void onBackPressed(){}
  public void setContentView(int id){}
  public <T extends android.view.View> T findViewById(int id){ return null; }
  public void requestPermissions(String[] p,int c){}
  public void startActivityForResult(Intent i,int c){}
  public void runOnUiThread(Runnable r){}
  public void finish(){}
  public Intent getIntent(){ return null; }
  public boolean isFinishing(){ return false; }
  public void onRequestPermissionsResult(int rc,String[] p,int[] g){}
  protected void onActivityResult(int rc,int rr,Intent d){}
  public SharedPreferences getPreferences(int m){ return null; }
  public void startActivity(Intent i){}
  public android.content.res.Resources.Theme getTheme(){ return null; }
  public android.view.Window getWindow(){ return null; }
  public boolean isInPictureInPictureMode(){ return false; }
  public void enterPictureInPictureMode(PictureInPictureParams p){}
  protected void onUserLeaveHint(){}
  public void onPictureInPictureModeChanged(boolean ip, android.content.res.Configuration c){}
  public boolean moveTaskToBack(boolean n){ return false; }
}
EOF

w android/app/AlertDialog.java <<'EOF'
package android.app;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
public class AlertDialog {
  public static final int BUTTON_NEUTRAL=-3, BUTTON_POSITIVE=-1, BUTTON_NEGATIVE=-2;
  public static class Builder {
    public Builder(Context c){}
    public Builder setTitle(CharSequence t){ return this; }
    public Builder setTitle(int r){ return this; }
    public Builder setMessage(CharSequence m){ return this; }
    public Builder setSingleChoiceItems(String[] i,int c,DialogInterface.OnClickListener l){ return this; }
    public Builder setItems(String[] i,DialogInterface.OnClickListener l){ return this; }
    public Builder setPositiveButton(CharSequence t,DialogInterface.OnClickListener l){ return this; }
    public Builder setNeutralButton(CharSequence t,DialogInterface.OnClickListener l){ return this; }
    public Builder setNegativeButton(CharSequence t,DialogInterface.OnClickListener l){ return this; }
    public Builder setView(View v){ return this; }
    public AlertDialog create(){ return new AlertDialog(); }
    public void show(){}
  }
  public AlertDialog(){}
  public void show(){}
  public void dismiss(){}
  public android.widget.Button getButton(int w){ return null; }
  public View findViewById(int id){ return null; }
}
EOF

w android/app/Application.java <<'EOF'
package android.app;
import android.content.Context;
public abstract class Application extends Context { public void onCreate(){} }
EOF
w android/app/Notification.java <<'EOF'
package android.app;
public class Notification { public static class Builder { public Builder(android.content.Context c,String ch){} } }
EOF
w android/app/NotificationChannel.java <<'EOF'
package android.app;
public class NotificationChannel {
  public NotificationChannel(String id,CharSequence n,int i){}
  public void setDescription(String s){} public void setShowBadge(boolean b){}
}
EOF
w android/app/NotificationManager.java <<'EOF'
package android.app;
public interface NotificationManager {
  int IMPORTANCE_LOW=2;
  void notify(int id,Notification n); void cancel(int id);
  void createNotificationChannel(NotificationChannel c);
}
EOF
w android/app/PendingIntent.java <<'EOF'
package android.app;
import android.content.Context;
import android.content.Intent;
public class PendingIntent {
  public static final int FLAG_UPDATE_CURRENT=0x8000000, FLAG_IMMUTABLE=0x04000000, FLAG_MUTABLE=0x02000000;
  public static PendingIntent getActivity(Context c,int code,Intent i,int f){ return null; }
}
EOF
w android/app/PictureInPictureParams.java <<'EOF'
package android.app;
public final class PictureInPictureParams {
  public static final class Builder {
    public Builder setAspectRatio(android.util.Rational r){ return this; }
    public PictureInPictureParams build(){ return null; }
  }
}
EOF

w android/content/Context.java <<'EOF'
package android.content;
import android.content.res.AssetManager;
import android.content.res.Resources;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
public abstract class Context {
  public static final int MODE_PRIVATE=0, MODE_APPEND=0x8000;
  public static final String CONNECTIVITY_SERVICE="c", CLIPBOARD_SERVICE="cb", INPUT_METHOD_SERVICE="im", NOTIFICATION_SERVICE="n";
  public Resources getResources(){ return null; }
  public File getFilesDir(){ return null; }
  public File getExternalFilesDir(String t){ return null; }
  public AssetManager getAssets(){ return null; }
  public Object getSystemService(String n){ return null; }
  public <T> T getSystemService(Class<T> s){ return null; }
  public String getPackageName(){ return null; }
  public FileOutputStream openFileOutput(String n,int m) throws IOException { return null; }
  public int checkCallingOrSelfPermission(String p){ return 0; }
  public int getColor(int id){ return 0; }
  public SharedPreferences getSharedPreferences(String n,int m){ return null; }
  public Context getApplicationContext(){ return this; }
}
EOF
w android/content/Intent.java <<'EOF'
package android.content;
import android.net.Uri;
public class Intent {
  public static final String ACTION_MAIN="m", ACTION_VIEW="v", ACTION_SEND="s";
  public static final int FLAG_ACTIVITY_NEW_TASK=0, FLAG_GRANT_READ_URI_PERMISSION=0, FLAG_ACTIVITY_CLEAR_TOP=0;
  public static final String EXTRA_TEXT="t", EXTRA_STREAM="st";
  public Intent(){} public Intent(Context c,Class<?> cls){} public Intent(String a){} public Intent(String a,Uri u){}
  public Intent putExtra(String k,String v){ return this; }
  public Intent putExtra(String k,Uri v){ return this; }
  public Intent setType(String t){ return this; }
  public Intent setDataAndType(Uri u,String t){ return this; }
  public Intent addFlags(int f){ return this; }
  public static Intent createChooser(Intent t,CharSequence s){ return null; }
  public String getStringExtra(String n){ return null; }
  public String getDataString(){ return null; }
  public ClipData getClipData(){ return null; }
  public Uri getData(){ return null; }
  public String getType(){ return null; }
}
EOF
w android/content/SharedPreferences.java <<'EOF'
package android.content;
public interface SharedPreferences {
  String getString(String k,String d);
  long getLong(String k,long d);
  boolean getBoolean(String k,boolean d);
  Editor edit();
  interface Editor { Editor putString(String k,String v); Editor putBoolean(String k,boolean v); Editor putLong(String k,long v); Editor remove(String k); void apply(); }
}
EOF
w android/content/DialogInterface.java <<'EOF'
package android.content;
public interface DialogInterface {
  public static final int BUTTON_NEUTRAL=-3;
  void dismiss();
  interface OnClickListener { void onClick(DialogInterface d,int w); }
}
EOF
w android/content/ClipData.java <<'EOF'
package android.content;
import android.net.Uri;
public class ClipData {
  public static ClipData newPlainText(CharSequence l,CharSequence t){ return null; }
  public int getItemCount(){ return 0; }
  public Item getItemAt(int i){ return null; }
  public static class Item { public Uri getUri(){ return null; } }
}
EOF
w android/content/ClipboardManager.java <<'EOF'
package android.content;
public class ClipboardManager { public void setPrimaryClip(ClipData c){} }
EOF
w android/content/pm/PackageManager.java <<'EOF'
package android.content.pm;
public class PackageManager { public static final int PERMISSION_GRANTED=0; }
EOF
w android/content/res/Resources.java <<'EOF'
package android.content.res;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
public class Resources {
  public DisplayMetrics getDisplayMetrics(){ return null; }
  public float getDimension(int id){ return 0f; }
  public int getIdentifier(String n,String t,String p){ return 0; }
  public Drawable getDrawable(int id){ return null; }
  public static class Theme { public boolean resolveAttribute(int a,android.util.TypedValue o,boolean r){ return false; } }
}
EOF
w android/content/res/AssetManager.java <<'EOF'
package android.content.res;
import java.io.IOException; import java.io.InputStream;
public class AssetManager { public InputStream open(String n) throws IOException { return null; } }
EOF
w android/content/res/Configuration.java <<'EOF'
package android.content.res;
public class Configuration {}
EOF

w android/net/Uri.java <<'EOF'
package android.net;
import java.io.File;
public class Uri {
  public static Uri parse(String s){ return null; }
  public static Uri fromFile(File f){ return null; }
  public String getHost(){ return null; }
  public String getPath(){ return null; }
  public String getScheme(){ return null; }
  public String toString(){ return null; }
}
EOF
w android/net/Network.java <<'EOF'
package android.net; public class Network {}
EOF
w android/net/NetworkCapabilities.java <<'EOF'
package android.net;
public class NetworkCapabilities {
  public static final int NET_CAPABILITY_INTERNET=0, TRANSPORT_CELLULAR=0, TRANSPORT_WIFI=1;
  public boolean hasTransport(int t){ return false; }
}
EOF
w android/net/NetworkRequest.java <<'EOF'
package android.net;
public class NetworkRequest { public static class Builder { public Builder addCapability(int c){ return this; } public NetworkRequest build(){ return null; } } }
EOF
w android/net/ConnectivityManager.java <<'EOF'
package android.net;
public class ConnectivityManager {
  public void registerNetworkCallback(NetworkRequest r,NetworkCallback c){}
  public void unregisterNetworkCallback(NetworkCallback c){}
  public Network getActiveNetwork(){ return null; }
  public NetworkCapabilities getNetworkCapabilities(Network n){ return null; }
  public static abstract class NetworkCallback { public void onCapabilitiesChanged(Network n,NetworkCapabilities c){} }
}
EOF

w android/os/Bundle.java <<'EOF'
package android.os;
public class Bundle { public void putString(String k,String v){} public String getString(String k,String d){ return d; } public String getString(String k){ return null; } }
EOF
w android/os/Build.java <<'EOF'
package android.os;
public class Build {
  public static class VERSION { public static int SDK_INT; }
  public static class VERSION_CODES { public static final int N=24, O=26; }
}
EOF
w android/os/Handler.java <<'EOF'
package android.os;
public class Handler { public Handler(Looper l){} public boolean post(Runnable r){ return false; } }
EOF
w android/os/Looper.java <<'EOF'
package android.os;
public class Looper { public static Looper getMainLooper(){ return null; } }
EOF

w android/text/Editable.java <<'EOF'
package android.text; public interface Editable extends CharSequence {}
EOF
w android/text/TextWatcher.java <<'EOF'
package android.text;
public interface TextWatcher { void beforeTextChanged(CharSequence s,int a,int b,int c); void onTextChanged(CharSequence s,int a,int b,int c); void afterTextChanged(Editable s); }
EOF
w android/text/InputType.java <<'EOF'
package android.text;
public class InputType {
  public static final int TYPE_CLASS_TEXT=1, TYPE_TEXT_VARIATION_URI=16, TYPE_TEXT_FLAG_NO_SUGGESTIONS=0x80000,
    TYPE_TEXT_FLAG_MULTI_LINE=0x20000, TYPE_TEXT_FLAG_CAP_SENTENCES=0x400000, TYPE_TEXT_FLAG_AUTO_CORRECT=0x8000,
    TYPE_TEXT_VARIATION_PASSWORD=128;
}
EOF
w android/text/TextUtils.java <<'EOF'
package android.text; public class TextUtils { public enum TruncateAt { START,MIDDLE,END,MARQUEE } }
EOF

w android/util/AttributeSet.java <<'EOF'
package android.util; public interface AttributeSet {}
EOF
w android/util/Log.java <<'EOF'
package android.util;
public class Log {
  public static int i(String t,String m){ return 0; } public static int w(String t,String m){ return 0; }
  public static int e(String t,String m){ return 0; } public static int d(String t,String m){ return 0; }
  public static int e(String t,String m,Throwable x){ return 0; } public static int w(String t,String m,Throwable x){ return 0; }
}
EOF
w android/util/DisplayMetrics.java <<'EOF'
package android.util; public class DisplayMetrics { public float density; public int widthPixels, heightPixels; }
EOF
w android/util/TypedValue.java <<'EOF'
package android.util;
public class TypedValue {
  public int resourceId;
  public static final int COMPLEX_UNIT_SP=2, COMPLEX_UNIT_DIP=1;
  public static float applyDimension(int u,float v,DisplayMetrics m){ return 0f; }
}
EOF
w android/util/Rational.java <<'EOF'
package android.util; public class Rational { public Rational(int w,int h){} }
EOF

w android/graphics/Bitmap.java <<'EOF'
package android.graphics; public class Bitmap {}
EOF
w android/graphics/Paint.java <<'EOF'
package android.graphics; public class Paint {}
EOF
w android/graphics/Typeface.java <<'EOF'
package android.graphics;
public class Typeface {
  public static Typeface DEFAULT, DEFAULT_BOLD, MONOSPACE;
  public static final int BOLD=1;
  public static Typeface create(Typeface f,int s){ return null; }
}
EOF
w android/graphics/drawable/Drawable.java <<'EOF'
package android.graphics.drawable; public abstract class Drawable {}
EOF
w android/graphics/drawable/GradientDrawable.java <<'EOF'
package android.graphics.drawable;
public class GradientDrawable extends Drawable { public void setColor(int c){} public void setCornerRadius(float r){} public void setStroke(int w,int c){} }
EOF

w android/view/MotionEvent.java <<'EOF'
package android.view;
public class MotionEvent {
  public static final int ACTION_DOWN=0, ACTION_UP=1, ACTION_MOVE=2, ACTION_CANCEL=3;
  public int getActionMasked(){ return 0; }
  public float getX(){ return 0f; } public float getY(){ return 0f; }
  public float getRawX(){ return 0f; } public float getRawY(){ return 0f; }
  public long getEventTime(){ return 0L; } public int getActionIndex(){ return 0; }
}
EOF
w android/view/Gravity.java <<'EOF'
package android.view;
public class Gravity { public static final int CENTER_HORIZONTAL=1, CENTER_VERTICAL=2, CENTER=0x11, START=0x800003, END=0x800005, BOTTOM=0x50, TOP=0x30; }
EOF
w android/view/IBinder.java <<'EOF'
package android.view; public interface IBinder {}
EOF
w android/view/ViewParent.java <<'EOF'
package android.view; public interface ViewParent {}
EOF
w android/view/ViewConfiguration.java <<'EOF'
package android.view;
import android.content.Context;
public class ViewConfiguration { public static ViewConfiguration get(Context c){ return null; } public int getScaledTouchSlop(){ return 0; } }
EOF
w android/view/HapticFeedbackConstants.java <<'EOF'
package android.view; public class HapticFeedbackConstants { public static final int VIRTUAL_KEY=0; }
EOF
w android/view/KeyEvent.java <<'EOF'
package android.view; public class KeyEvent {}
EOF
w android/view/Window.java <<'EOF'
package android.view;
public abstract class Window {
  public void setBackgroundDrawableResource(int r){}
  public View getDecorView(){ return null; }
}
EOF
w android/view/LayoutInflater.java <<'EOF'
package android.view;
import android.content.Context;
public abstract class LayoutInflater {
  public static LayoutInflater from(Context c){ return null; }
  public View inflate(int r,ViewGroup root,boolean a){ return null; }
  public View inflate(int r,ViewGroup root){ return null; }
}
EOF
w android/view/ViewPropertyAnimator.java <<'EOF'
package android.view;
public class ViewPropertyAnimator {
  public ViewPropertyAnimator translationY(float v){ return this; }
  public ViewPropertyAnimator translationX(float v){ return this; }
  public ViewPropertyAnimator alpha(float v){ return this; }
  public ViewPropertyAnimator scaleX(float v){ return this; }
  public ViewPropertyAnimator scaleY(float v){ return this; }
  public ViewPropertyAnimator setDuration(long d){ return this; }
  public ViewPropertyAnimator start(){ return this; }
  public ViewPropertyAnimator withEndAction(Runnable r){ return this; }
}
EOF
w android/view/View.java <<'EOF'
package android.view;
import android.content.Context;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
public class View {
  public static final int VISIBLE=0, GONE=8, LAYER_TYPE_HARDWARE=2, OVER_SCROLL_NEVER=2, FOCUS_DOWN=130;
  public View(Context c){} public View(Context c,AttributeSet a){} public View(Context c,AttributeSet a,int d){}
  public void setLayoutParams(ViewGroup.LayoutParams p){}
  public ViewGroup.LayoutParams getLayoutParams(){ return null; }
  public void setOnClickListener(OnClickListener l){}
  public void setOnLongClickListener(OnLongClickListener l){}
  public void setOnFocusChangeListener(OnFocusChangeListener l){}
  public void setBackground(Drawable d){}
  public void setBackgroundResource(int id){}
  public void setPadding(int a,int b,int c,int d){}
  public void setClickable(boolean c){}
  public void setVisibility(int v){}
  public void setEnabled(boolean e){}
  public void setAlpha(float a){}
  public void setRotation(float r){}
  public void setContentDescription(CharSequence c){}
  public void setScaleX(float x){}
  public void setScaleY(float y){}
  public void setVerticalScrollBarEnabled(boolean b){}
  public void setOverScrollMode(int m){}
  public void setBackgroundColor(int c){}
  public void setTranslationY(float v){}
  public void setTranslationX(float v){}
  public void setElevation(float e){}
  public int getWidth(){ return 0; } public int getHeight(){ return 0; }
  public int getMeasuredHeight(){ return 0; } public int getMeasuredWidth(){ return 0; }
  public float getX(){ return 0f; } public float getY(){ return 0f; }
  public void setX(float x){} public void setY(float y){}
  public ViewParent getParent(){ return null; }
  public IBinder getWindowToken(){ return null; }
  public boolean performHapticFeedback(int c){ return false; }
  public void setLayerType(int l,Paint p){}
  public void requestLayout(){}
  public void measure(int ws,int hs){}
  public Context getContext(){ return null; }
  public <T extends View> T findViewById(int id){ return null; }
  public void post(Runnable r){}
  public boolean setOnTouchListener(OnTouchListener l){ return true; }
  public int getVisibility(){ return 0; }
  public android.view.ViewPropertyAnimator animate(){ return null; }
  public boolean requestFocus(){ return true; }
  public interface OnClickListener { void onClick(View v); }
  public interface OnFocusChangeListener { void onFocusChange(View v,boolean h); }
  public interface OnLongClickListener { boolean onLongClick(View v); }
  public interface OnTouchListener { boolean onTouch(View v,MotionEvent e); }
  public static final class MeasureSpec { public static final int EXACTLY=0x40000000, UNSPECIFIED=0; public static int makeMeasureSpec(int s,int m){ return 0; } }
}
EOF
w android/view/ViewGroup.java <<'EOF'
package android.view;
import android.content.Context;
import android.util.AttributeSet;
public abstract class ViewGroup extends View {
  public ViewGroup(Context c){ super(c); } public ViewGroup(Context c,AttributeSet a){ super(c,a); } public ViewGroup(Context c,AttributeSet a,int d){ super(c,a,d); }
  public void removeView(View v){}
  public int getChildCount(){ return 0; }
  public View getChildAt(int i){ return null; }
  public void addView(View v){}
  public void addView(View v,int index){}
  public void removeViewAt(int i){}
  public void removeAllViews(){}
  public static class LayoutParams { public static final int MATCH_PARENT=-1, WRAP_CONTENT=-2; public int width, height; public LayoutParams(int w,int h){} public LayoutParams(){} }
  public static class MarginLayoutParams extends LayoutParams { public int topMargin,bottomMargin,leftMargin,rightMargin; public MarginLayoutParams(){} public MarginLayoutParams(int w,int h){ super(w,h); } public void setMargins(int a,int b,int c,int d){} }
}
EOF
w android/view/inputmethod/EditorInfo.java <<'EOF'
package android.view.inputmethod;
public class EditorInfo { public static final int IME_ACTION_GO=2, IME_ACTION_SEARCH=3, IME_ACTION_DONE=6, IME_ACTION_SEND=4; }
EOF
w android/view/inputmethod/InputMethodManager.java <<'EOF'
package android.view.inputmethod;
import android.view.IBinder;
public class InputMethodManager { public void hideSoftInputFromWindow(IBinder t,int f){} }
EOF

w android/webkit/CookieManager.java <<'EOF'
package android.webkit;
public class CookieManager {
  public static CookieManager getInstance(){ return null; }
  public void setAcceptCookie(boolean a){} public void setAcceptThirdPartyCookies(WebView v,boolean a){}
  public void flush(){} public void removeAllCookies(ValueCallback<Boolean> c){}
}
EOF
w android/webkit/GeolocationPermissions.java <<'EOF'
package android.webkit; public class GeolocationPermissions { public interface Callback { void invoke(String o,boolean a,boolean r); } }
EOF
w android/webkit/JavascriptInterface.java <<'EOF'
package android.webkit;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) public @interface JavascriptInterface {}
EOF
w android/webkit/PermissionRequest.java <<'EOF'
package android.webkit;
public class PermissionRequest {
  public static final String RESOURCE_VIDEO_CAPTURE="v", RESOURCE_AUDIO_CAPTURE="a";
  public String[] getResources(){ return null; } public void grant(String[] r){} public void deny(){}
}
EOF
w android/webkit/SafeBrowsingResponse.java <<'EOF'
package android.webkit; public class SafeBrowsingResponse { public void backToSafety(boolean b){} public void proceed(boolean b){} }
EOF
w android/webkit/SslError.java <<'EOF'
package android.webkit; public class SslError {}
EOF
w android/webkit/SslErrorHandler.java <<'EOF'
package android.webkit; public class SslErrorHandler { public void cancel(){} public void proceed(){} }
EOF
w android/webkit/ValueCallback.java <<'EOF'
package android.webkit; public interface ValueCallback<T> { void onReceiveValue(T v); }
EOF
w android/webkit/WebBackForwardList.java <<'EOF'
package android.webkit; public class WebBackForwardList {}
EOF
w android/webkit/WebChromeClient.java <<'EOF'
package android.webkit;
import android.content.Intent;
public class WebChromeClient {
  public void onProgressChanged(WebView v,int p){} public void onReceivedTitle(WebView v,String t){}
  public void onGeolocationPermissionsShowPrompt(String o,GeolocationPermissions.Callback c){}
  public void onPermissionRequest(PermissionRequest r){}
  public boolean onShowFileChooser(WebView v,ValueCallback<android.net.Uri[]> c,FileChooserParams p){ return false; }
  public void onConsoleMessage(String m,int l,String s){}
  public static abstract class FileChooserParams { public Intent createIntent(){ return null; } }
}
EOF
w android/webkit/WebResourceRequest.java <<'EOF'
package android.webkit; import android.net.Uri;
public interface WebResourceRequest { Uri getUrl(); boolean isForMainFrame(); }
EOF
w android/webkit/WebResourceResponse.java <<'EOF'
package android.webkit;
import java.io.InputStream;
public class WebResourceResponse { public WebResourceResponse(String m,String e,InputStream d){} }
EOF
w android/webkit/WebSettings.java <<'EOF'
package android.webkit;
public class WebSettings {
  public static final int MIXED_CONTENT_NEVER_ALLOW=1, MIXED_CONTENT_COMPATIBILITY_MODE=2, LOAD_DEFAULT=0, LOAD_CACHE_ELSE_NETWORK=1;
  public static final class LayoutAlgorithm { public static final LayoutAlgorithm NORMAL = new LayoutAlgorithm(); }
  public void setJavaScriptEnabled(boolean b){} public void setDomStorageEnabled(boolean b){} public void setDatabaseEnabled(boolean b){}
  public void setSupportZoom(boolean b){} public void setBuiltInZoomControls(boolean b){} public void setDisplayZoomControls(boolean b){}
  public void setLoadWithOverviewMode(boolean b){} public void setUseWideViewPort(boolean b){} public void setTextZoom(int z){}
  public void setMediaPlaybackRequiresUserGesture(boolean b){} public void setAllowFileAccess(boolean b){}
  public void setAllowFileAccessFromFileURLs(boolean b){} public void setAllowUniversalAccessFromFileURLs(boolean b){}
  public void setMixedContentMode(int m){} public void setJavaScriptCanOpenWindowsAutomatically(boolean b){}
  public void setSupportMultipleWindows(boolean b){} public void setGeolocationEnabled(boolean b){}
  public void setCacheMode(int m){} public void setBlockNetworkImage(boolean b){} public void setLayoutAlgorithm(LayoutAlgorithm a){}
  public void setSafeBrowsingEnabled(boolean b){} public void setUserAgentString(String u){} public String getUserAgentString(){ return null; }
}
EOF
w android/webkit/WebStorage.java <<'EOF'
package android.webkit; public class WebStorage { public static WebStorage getInstance(){ return null; } public void deleteAllData(){} }
EOF
w android/webkit/WebView.java <<'EOF'
package android.webkit;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.AttributeSet;
public class WebView extends android.view.ViewGroup {
  public WebView(Context c){ super(c); } public WebView(Context c,AttributeSet a){ super(c,a); } public WebView(Context c,AttributeSet a,int d){ super(c,a,d); }
  public WebSettings getSettings(){ return null; }
  public void setWebViewClient(WebViewClient c){} public void setWebChromeClient(WebChromeClient c){}
  public void addJavascriptInterface(Object o,String n){} public void removeJavascriptInterface(String n){}
  public void loadUrl(String u){} public void evaluateJavascript(String j,ValueCallback<String> c){}
  public boolean canGoBack(){ return false; } public boolean canGoForward(){ return false; }
  public void goBack(){} public void goForward(){} public void reload(){} public void stopLoading(){}
  public String getUrl(){ return null; }
  public void clearCache(boolean b){} public void clearHistory(){} public void clearFormData(){} public void destroy(){}
  public WebBackForwardList saveState(Bundle b){ return null; } public WebBackForwardList restoreState(Bundle b){ return null; }
  public void setHorizontalScrollBarEnabled(boolean b){}
  public boolean onTouchEvent(android.view.MotionEvent e){ return false; }
  protected void onScrollChanged(int l,int t,int ol,int ot){}
}
EOF
w android/webkit/WebViewClient.java <<'EOF'
package android.webkit;
import android.graphics.Bitmap;
public class WebViewClient {
  public void onPageStarted(WebView v,String u,Bitmap f){} public void onPageFinished(WebView v,String u){}
  public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){ return null; }
  public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){ return false; }
  public void onReceivedSslError(WebView v,SslErrorHandler h,SslError e){}
  public void onSafeBrowsingHit(WebView v,WebResourceRequest r,int t,SafeBrowsingResponse s){}
}
EOF
w android/webkit/URLUtil.java <<'EOF'
package android.webkit; public class URLUtil { public static boolean isNetworkUrl(String u){ return false; } }
EOF

# widgets
mkd android/widget
w android/widget/TextView.java <<'EOF'
package android.widget;
import android.content.Context;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
public class TextView extends android.view.View {
  public TextView(Context c){ super(c); } public TextView(Context c,AttributeSet a){ super(c,a); }
  public void setText(CharSequence t){} public void setText(String t){}
  public void setTextColor(int c){} public void setTextSize(int u,float s){}
  public void setGravity(int g){} public void setTypeface(Typeface t){}
  public void setSingleLine(boolean s){} public void setHint(int r){} public void setHint(CharSequence h){}
  public void setSelection(int i){} public void selectAll(){} public void setInputType(int t){}
  public void setMinLines(int n){} public void setEllipsize(TextUtils.TruncateAt w){}
  public void setMarqueeRepeatLimit(int n){} public void setSelected(boolean s){}
  public void setImeOptions(int o){} public void setHintTextColor(int c){} public void setMaxLines(int n){}
  public void setOnEditorActionListener(OnEditorActionListener l){}
  public interface OnEditorActionListener { boolean onEditorAction(TextView v,int a,KeyEvent e); }
}
EOF
w android/widget/EditText.java <<'EOF'
package android.widget;
import android.content.Context; import android.text.Editable; import android.text.TextWatcher; import android.util.AttributeSet;
public class EditText extends TextView {
  public EditText(Context c){ super(c); } public EditText(Context c,AttributeSet a){ super(c,a); }
  public Editable getText(){ return null; } public void addTextChangedListener(TextWatcher w){}
}
EOF
w android/widget/Button.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public class Button extends TextView { public Button(Context c){ super(c); } public Button(Context c,AttributeSet a){ super(c,a); } public void setOnClickListener(android.view.View.OnClickListener l){} }
EOF
w android/widget/CompoundButton.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public abstract class CompoundButton extends Button {
  public CompoundButton(Context c){ super(c); } public CompoundButton(Context c,AttributeSet a){ super(c,a); }
  public void setChecked(boolean c){} public void setOnCheckedChangeListener(OnCheckedChangeListener l){}
  public interface OnCheckedChangeListener { void onCheckedChanged(CompoundButton b,boolean c); }
}
EOF
w android/widget/Switch.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public class Switch extends CompoundButton { public Switch(Context c){ super(c); } public Switch(Context c,AttributeSet a){ super(c,a); } }
EOF
w android/widget/CheckBox.java <<'EOF'
package android.widget; import android.content.Context;
public class CheckBox extends CompoundButton { public CheckBox(Context c){ super(c); } public void setText(CharSequence t){} }
EOF
w android/widget/ImageView.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ImageView extends android.view.View {
  public ImageView(Context c){ super(c); } public ImageView(Context c,AttributeSet a){ super(c,a); }
  public void setImageResource(int r){} public enum ScaleType { CENTER } public void setScaleType(ScaleType t){}
}
EOF
w android/widget/ImageButton.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ImageButton extends ImageView { public ImageButton(Context c){ super(c); } public ImageButton(Context c,AttributeSet a){ super(c,a); } }
EOF
w android/widget/ProgressBar.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ProgressBar extends android.view.View {
  public ProgressBar(Context c){ super(c); } public ProgressBar(Context c,AttributeSet a){ super(c,a); }
  public void setProgress(int p){} public void setMax(int m){} public void setIndeterminate(boolean b){}
}
EOF
w android/widget/FrameLayout.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup;
public class FrameLayout extends ViewGroup {
  public FrameLayout(Context c){ super(c); } public FrameLayout(Context c,AttributeSet a){ super(c,a); }
  public static class LayoutParams extends MarginLayoutParams { public int gravity; public LayoutParams(int w,int h){ super(w,h); } }
}
EOF
w android/widget/ScrollView.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ScrollView extends FrameLayout {
  public ScrollView(Context c){ super(c); } public ScrollView(Context c,AttributeSet a){ super(c,a); }
  public void fullScroll(int d){}
}
EOF
w android/widget/LinearLayout.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup;
public class LinearLayout extends ViewGroup {
  public LinearLayout(Context c){ super(c); } public LinearLayout(Context c,AttributeSet a){ super(c,a); }
  public static final int VERTICAL=1, HORIZONTAL=0;
  public void setOrientation(int o){} public void setGravity(int g){}
  public static class LayoutParams extends MarginLayoutParams { public float weight; public int gravity; public LayoutParams(int w,int h){ super(w,h); } public LayoutParams(int w,int h,float ww){ super(w,h); weight=ww; } }
}
EOF
w android/widget/GridLayout.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup;
public class GridLayout extends ViewGroup {
  public GridLayout(Context c){ super(c); } public GridLayout(Context c,AttributeSet a){ super(c,a); }
  public static final int UNDEFINED=Integer.MIN_VALUE;
  public static Spec spec(int s,int sz,float w){ return null; } public static Spec spec(int s,int sz){ return null; } public static Spec spec(int sz){ return null; }
  public static class Spec {}
  public static class LayoutParams extends MarginLayoutParams { public Spec rowSpec, columnSpec; public LayoutParams(){} public LayoutParams(int w,int h){ super(w,h); } public void setGravity(int g){} }
}
EOF
w android/widget/ViewAnimator.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ViewAnimator extends FrameLayout {
  public ViewAnimator(Context c){ super(c); } public ViewAnimator(Context c,AttributeSet a){ super(c,a); }
  public void setDisplayedChild(int i){} public int getDisplayedChild(){ return 0; }
}
EOF
w android/widget/ViewFlipper.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public class ViewFlipper extends ViewAnimator { public ViewFlipper(Context c){ super(c); } public ViewFlipper(Context c,AttributeSet a){ super(c,a); } }
EOF
w android/widget/Toast.java <<'EOF'
package android.widget; import android.content.Context;
public class Toast { public static final int LENGTH_SHORT=0; public static Toast makeText(Context c,CharSequence t,int d){ return null; } public void show(){} }
EOF
w android/widget/AdapterView.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup;
public abstract class AdapterView<T> extends ViewGroup {
  public AdapterView(Context c){ super(c); } public AdapterView(Context c,AttributeSet a){ super(c,a); }
  public interface OnItemSelectedListener { void onItemSelected(AdapterView<?> p,android.view.View v,int pos,long idl); void onNothingSelected(AdapterView<?> p); }
  public interface Adapter {}
  public interface SpinnerAdapter extends Adapter {}
}
EOF
w android/widget/Spinner.java <<'EOF'
package android.widget; import android.content.Context; import android.util.AttributeSet;
public class Spinner extends AdapterView {
  public Spinner(Context c){ super(c); } public Spinner(Context c,AttributeSet a){ super(c,a); }
  public void setAdapter(SpinnerAdapter a){} public void setSelection(int i){} public int getSelection(){ return 0; }
  public void setOnItemSelectedListener(OnItemSelectedListener l){}
}
EOF
w android/widget/ArrayAdapter.java <<'EOF'
package android.widget; import android.content.Context; import java.util.List;
public class ArrayAdapter<T> implements AdapterView.SpinnerAdapter {
  public ArrayAdapter(Context c,int r,T[] o){} public ArrayAdapter(Context c,int r,List<T> o){}
  public void setDropDownViewResource(int r){}
}
EOF

# android.R + android.Manifest
w android/Manifest.java <<'EOF'
package android;
public class Manifest { public static final class permission {
  public static final String CAMERA="c", RECORD_AUDIO="r", ACCESS_FINE_LOCATION="fl", ACCESS_COARSE_LOCATION="cl";
}}
EOF
w android/R.java <<'EOF'
package android;
public final class R {
  public static final class attr { public static final int selectableItemBackground=0x0101038f; }
  public static final class id { public static final int content=0x01020002; }
  public static final class layout { public static final int simple_spinner_item=0x01090000; public static final int simple_spinner_dropdown_item=0x01090001; }
  public static final class color { public static final int black=0x01020000, white=0x01020001; }
  public static final class drawable { public static final int stat_sys_download=0x0108005a; }
}
EOF

# androidx
w androidx/annotation/Nullable.java <<'EOF'
package androidx.annotation; import java.lang.annotation.*;
@Retention(RetentionPolicy.CLASS) public @interface Nullable {}
EOF
w androidx/annotation/NonNull.java <<'EOF'
package androidx.annotation; import java.lang.annotation.*;
@Retention(RetentionPolicy.CLASS) public @interface NonNull {}
EOF
w androidx/annotation/OptIn.java <<'EOF'
package androidx.annotation; import java.lang.annotation.*;
@Retention(RetentionPolicy.CLASS) public @interface OptIn { Class<?>[] markerClass(); }
EOF
w androidx/appcompat/app/AppCompatActivity.java <<'EOF'
package androidx.appcompat.app;
import android.app.Activity; import android.os.Bundle;
public class AppCompatActivity extends Activity {
  protected void onCreate(Bundle b){} protected void onStart(){} protected void onStop(){}
}
EOF
w androidx/core/app/NotificationCompat.java <<'EOF'
package androidx.core.app;
import android.app.Notification;
public class NotificationCompat {
  public static final int PRIORITY_LOW=-1;
  public static class Builder {
    public Builder(android.content.Context c,String ch){}
    public Builder setSmallIcon(int i){ return this; } public Builder setContentTitle(CharSequence t){ return this; }
    public Builder setContentText(CharSequence t){ return this; } public Builder setProgress(int m,int p,boolean i){ return this; }
    public Builder setOngoing(boolean b){ return this; } public Builder setAutoCancel(boolean b){ return this; }
    public Builder setOnlyAlertOnce(boolean b){ return this; } public Builder setContentIntent(android.app.PendingIntent p){ return this; }
    public Builder setPriority(int p){ return this; } public Notification build(){ return null; }
  }
}
EOF
w androidx/core/content/FileProvider.java <<'EOF'
package androidx.core.content;
import android.net.Uri; import java.io.File;
public class FileProvider { public static Uri getUriForFile(android.content.Context c,String a,File f){ return null; } }
EOF
w androidx/core/view/WindowCompat.java <<'EOF'
package androidx.core.view;
import android.view.View; import android.view.Window;
public final class WindowCompat {
  public static void setDecorFitsSystemWindows(Window w,boolean b){}
  public static WindowInsetsControllerCompat getInsetsController(Window w,View v){ return null; }
}
EOF
w androidx/core/view/WindowInsetsCompat.java <<'EOF'
package androidx.core.view;
public final class WindowInsetsCompat { public static final class Type { public static int systemBars(){ return 0; } } }
EOF
w androidx/core/view/WindowInsetsControllerCompat.java <<'EOF'
package androidx.core.view;
public final class WindowInsetsControllerCompat {
  public static final int BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE=1;
  public void hide(int t){} public void show(int t){} public void setSystemBarsBehavior(int b){}
}
EOF
w androidx/recyclerview/widget/RecyclerView.java <<'EOF'
package androidx.recyclerview.widget;
import android.content.Context; import android.util.AttributeSet; import android.view.ViewGroup; import android.view.View;
public class RecyclerView extends ViewGroup {
  public RecyclerView(Context c){ super(c); } public RecyclerView(Context c,AttributeSet a){ super(c,a); }
  public void setLayoutManager(LayoutManager l){} public void setAdapter(Adapter a){}
  public abstract static class LayoutManager {}
  public abstract static class Adapter<VH extends ViewHolder> {
    public abstract VH onCreateViewHolder(ViewGroup p,int vt);
    public abstract void onBindViewHolder(VH h,int pos);
    public abstract int getItemCount();
  }
  public abstract static class ViewHolder { public final View itemView; public ViewHolder(View v){ itemView=v; } }
}
EOF
w androidx/recyclerview/widget/LinearLayoutManager.java <<'EOF'
package androidx.recyclerview.widget; import android.content.Context;
public class LinearLayoutManager extends RecyclerView.LayoutManager { public LinearLayoutManager(Context c){} }
EOF
w androidx/recyclerview/widget/DiffUtil.java <<'EOF'
package androidx.recyclerview.widget;
public abstract class DiffUtil {
  public abstract static class Callback {
    public abstract int getOldListSize(); public abstract int getNewListSize();
    public abstract boolean areItemsTheSame(int o,int n); public abstract boolean areContentsTheSame(int o,int n);
  }
  public static DiffResult calculateDiff(Callback c){ return null; }
  public interface DiffResult { void dispatchUpdatesTo(RecyclerView.Adapter a); }
}
EOF
w androidx/media3/common/MediaItem.java <<'EOF'
package androidx.media3.common;
public final class MediaItem {
  public static final class Builder {
    public Builder(){} public Builder setUri(Object u){ return this; } public Builder setMimeType(String m){ return this; } public MediaItem build(){ return null; }
  }
  public static MediaItem fromUri(Object u){ return null; }
}
EOF
w androidx/media3/common/Player.java <<'EOF'
package androidx.media3.common;
public interface Player {
  void setMediaItem(MediaItem m); void prepare(); void setPlayWhenReady(boolean b); boolean getPlayWhenReady();
  void release(); void addListener(Listener l);
  interface Listener { default void onVideoSizeChanged(VideoSize v){} }
}
EOF
w androidx/media3/common/VideoSize.java <<'EOF'
package androidx.media3.common; public final class VideoSize { public int width, height; }
EOF
w androidx/media3/common/util/UnstableApi.java <<'EOF'
package androidx.media3.common.util; import java.lang.annotation.*;
@Retention(RetentionPolicy.CLASS) public @interface UnstableApi {}
EOF
w androidx/media3/exoplayer/ExoPlayer.java <<'EOF'
package androidx.media3.exoplayer; import androidx.media3.common.Player;
public interface ExoPlayer extends Player { final class Builder { public Builder(Object c){} public ExoPlayer build(){ return null; } } }
EOF
w androidx/media3/ui/PlayerView.java <<'EOF'
package androidx.media3.ui;
import android.content.Context; import android.util.AttributeSet; import android.widget.FrameLayout; import androidx.media3.common.Player;
public class PlayerView extends FrameLayout {
  public PlayerView(Context c){ super(c); } public PlayerView(Context c,AttributeSet a){ super(c,a); }
  public void setPlayer(Player p){} public void setUseController(boolean b){}
}
EOF

# org
w org/json/JSONArray.java <<'EOF'
package org.json;
public class JSONArray {
  public JSONArray(){} public JSONArray(String s) throws JSONException {}
  public int length(){ return 0; }
  public String getString(int i) throws JSONException { return null; }
  public JSONObject getJSONObject(int i) throws JSONException { return null; }
  public JSONArray put(JSONObject o){ return this; }
}
EOF
w org/json/JSONException.java <<'EOF'
package org.json; public class JSONException extends Exception { public JSONException(String s){ super(s); } }
EOF
w org/json/JSONObject.java <<'EOF'
package org.json;
public class JSONObject {
  public JSONObject(){} public JSONObject(String s) throws JSONException {}
  public JSONObject put(String k,Object v) throws JSONException { return this; }
  public JSONObject put(String k,int v) throws JSONException { return this; }
  public JSONObject put(String k,long v) throws JSONException { return this; }
  public JSONObject put(String k,boolean v) throws JSONException { return this; }
  public String optString(String k,String d){ return d; } public String optString(String k){ return null; }
  public int optInt(String k,int d){ return d; } public long optLong(String k,long d){ return d; }
  public JSONArray optJSONArray(String k){ return null; }
  public JSONObject getJSONObject(String k) throws JSONException { return null; }
}
EOF
w org/json/JSONTokener.java <<'EOF'
package org.json; public class JSONTokener { public JSONTokener(String s){} public Object nextValue() throws JSONException { return null; } }
EOF
w org/xmlpull/v1/XmlPullParser.java <<'EOF'
package org.xmlpull.v1;
public interface XmlPullParser {
  int START_TAG=2, END_TAG=3, TEXT=4, END_DOCUMENT=1, IGNORABLE_WHITESPACE=7;
  void setInput(java.io.Reader r) throws XmlPullParserException, java.io.IOException;
  int getEventType() throws XmlPullParserException, java.io.IOException;
  int next() throws XmlPullParserException, java.io.IOException;
  String getName(); String getAttributeValue(String ns,String n); String getText(); int getDepth();
}
EOF
w org/xmlpull/v1/XmlPullParserException.java <<'EOF'
package org.xmlpull.v1; public class XmlPullParserException extends Exception { public XmlPullParserException(String s){ super(s); } }
EOF
w org/xmlpull/v1/XmlPullParserFactory.java <<'EOF'
package org.xmlpull.v1;
public class XmlPullParserFactory {
  public static XmlPullParserFactory newInstance() throws XmlPullParserException { return new XmlPullParserFactory(); }
  public void setNamespaceAware(boolean b){}
  public XmlPullParser newPullParser() throws XmlPullParserException { return null; }
}
EOF

# java.io/nio
w java/io/File.java <<'EOF'
package java.io;
public class File {
  public File(String p){} public File(File p,String c){}
  public boolean exists(){ return false; } public boolean mkdirs(){ return false; } public boolean mkdir(){ return false; }
  public boolean delete(){ return false; } public boolean renameTo(File d){ return false; }
  public String getName(){ return null; } public String getAbsolutePath(){ return null; } public String getPath(){ return null; }
  public File[] listFiles(){ return null; } public boolean isFile(){ return false; }
  public java.nio.file.Path toPath(){ return null; }
}
EOF
w java/nio/file/Files.java <<'EOF'
package java.nio.file; import java.io.IOException;
public class Files { public static byte[] readAllBytes(Path p) throws IOException { return new byte[0]; } }
EOF
w java/nio/file/Path.java <<'EOF'
package java.nio.file; public interface Path {}
EOF
w java/nio/file/Paths.java <<'EOF'
package java.nio.file; public class Paths { public static Path get(String f,String... m){ return null; } }
EOF

# --------------------------- R.java (auto from source refs) ---------------------------
APP=/home/user/app/src/main/java
{
  echo "package com.minibrowser;"
  echo "public final class R {"
  for cat in layout id drawable color string dimen; do
    echo "  public static final class $cat {"
    n=1
    declare -A seen=()
    for ref in $(grep -rhoE "R\.$cat\.[A-Za-z0-9_]+" "$APP" | sort -u); do
      name="${ref#R.$cat.}"
      if [ -z "${seen[$name]:-}" ]; then
        echo "    public static final int $name=$((n));"
        n=$((n+1)); seen[$name]=1
      fi
    done
    echo "  }"
  done
  echo "}"
} > com/minibrowser/R.java

echo ">> stubs + R.java generated"
